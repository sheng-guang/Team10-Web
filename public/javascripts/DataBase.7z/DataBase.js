/*
 *  Copyright (C) The University of Sheffield - All Rights Reserved
 *  Written by Fabio Ciravegna (f.ciravegna@shef.ac.uk)
 *
 */

import * as idb from 'https://cdn.jsdelivr.net/npm/idb@7/+esm';
import {VERSION} from "ejs";

var db;

const DB_Name= 'db_Secrets';

function ensure_Collection(db,to){
    console.log(to);
    if (db.objectStoreNames.contains(to))return;
    let Store = db.createObjectStore(to, {
        keyPath: 'id',
        autoIncrement: true
    });
    if(Store)created.put(to);
}
var toCreat={}
function upgrade(db,oldVersion, newVersion){
    toCreat.forEach(x=>{
        ensure_Collection(db,x);
    })
}
window.initDatabase=async function initDatabase(collection_name){
    console.log("ensure "+collection_name);
    if(!db)db=await idb.openDB(DB_Name);
    console.log( db.VERSION);
    // toCreat.put(collection_name);
    // db = await idb.openDB(DB_Name, 2, {upgrade});
}
const stories="stories";
window.StoreStory=async function StoreStory(storyObj){
    await initDatabase(stories);
    if(!db)return;
    try{
        let tx = await db.transaction(stories, 'readwrite');
        let store = await tx.objectStore(stories);
        await store.put(storyObj);
        await  tx.complete;
        console.log('added item to the store! '+ JSON.stringify(storyObj));
    } catch(error) {
        console.log('error: I could not store the element. Reason: '+error);
    }

}

window.GetAllStory=async function GetAllStory(){
    await initDatabase(stories);
    if(!db)return;
    try{
        let tx = await db.transaction(stories, 'readonly');
        let store = await tx.objectStore(stories);
        let all=  store.getAll();
        // console.log("================================get all  ");
        // console.log(all);
        // console.log("get all  ================================");
        return all;
    } catch(error) {
        console.log('error: I could not store the element. Reason: '+error);
    }

}

window.StoreTalk=async  function StoreTalk(username,room,from,line){
    await initDatabase();
    if(!db)return;
    let key=username+"|"+room;
    let to={key:key, from:from,line:line};
    try{
        let tx = await db.transaction(talk, 'readwrite');
        let store = await tx.objectStore(talk);
        await store.put(to);
        await  tx.complete;
        console.log('added item to the store! '+ JSON.stringify(to));
    } catch(error) {
        console.log('error: I could not store the element. Reason: '+error);
    }
}
window.getAllTalk=async function getAllTalk(username,room){
    await initDatabase();
    if(!db)return;
    let key=username+"|"+room;
    try{
        let tx = await db.transaction(stories, 'readonly');
        let store = await tx.objectStore(stories);
        let all=  store.index("key").get(key)
        return all;
    } catch(error) {
        console.log('error: I could not store the element. Reason: '+error);
    }
}
export default null;